const http = require('http');
const app = require('./app');
const connectWithDb = require('./db/db');


const PORT = 8000;
const hostName = "127.0.0.7";

const server = http.createServer(app);

server.listen(PORT, hostName, async () => {
    await connectWithDb()
    console.log(`server started with http://${hostName}:${PORT}`);
})


module.exports = app
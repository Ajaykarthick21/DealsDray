import React from 'react';
import { BrowserRouter, Routes, Route ,Link} from "react-router-dom";
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import CreateUser from './components/CreateUser';
import UserList from './components/UserList';
import UserEdit from './components/UserEdit';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <nav >
          <ul>
            <li><Link to="login">Login</Link></li>
            <li><Link to="/dashboard">Dashboard</Link></li>
            <li><Link to="/create-user">CreateUser</Link></li>
            <li><Link to="/user-list">UserList</Link></li>
            <li><Link to="/user-edit/:id">UserEdit</Link></li>
          </ul>
        </nav>



        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/create-user" element={<CreateUser />} />
          <Route path="/user-list" element={<UserList />} />
          <Route path="/user-edit/:id" element={<UserEdit />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;

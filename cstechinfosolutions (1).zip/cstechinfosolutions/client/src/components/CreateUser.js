import React, { useState } from 'react';

const CreateUser = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobileNo: '',
    designation: 'Sales',
    gender: 'M',
    courses: []
  });

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === 'checkbox') {
      const updatedCourses = checked
        ? [...formData.courses, value]
        : formData.courses.filter((course) => course !== value);

      setFormData({ ...formData, courses: updatedCourses });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleFileUpload = (e) => {
    // Handle file upload logic here
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name</label>
        <input type="text" name="name" value={formData.name} onChange={handleInputChange} />
      </div>
      <div>
        <label>Email</label>
        <input type="text" name="email" value={formData.email} onChange={handleInputChange} />
      </div>
      <div>
        <label>Mobile No</label>
        <input type="text" name="mobileNo" value={formData.mobileNo} onChange={handleInputChange} />
      </div>
      <div>
        <label>Designation</label>
        <select name="designation" value={formData.designation} onChange={handleInputChange}>
          <option value="Sales">Sales</option>
          <option value="HR">HR</option>
          <option value="Operations">Operations</option>
        </select>
      </div>
      <div>
        <label>Gender</label>
        <label>
          <input type="radio" name="gender" value="M" checked={formData.gender === 'M'} onChange={handleInputChange} /> Male
        </label>
        <label>
          <input type="radio" name="gender" value="F" checked={formData.gender === 'F'} onChange={handleInputChange} /> Female
        </label>
      </div>
      <div>
        <label>Course</label>
        <label>
          <input type="checkbox" name="courses" value="MCA" checked={formData.courses.includes('MCA')} onChange={handleInputChange} /> MCA
        </label>
        <label>
          <input type="checkbox" name="courses" value="BCA" checked={formData.courses.includes('BCA')} onChange={handleInputChange} /> BCA
        </label>
        <label>
          <input type="checkbox" name="courses" value="BSC" checked={formData.courses.includes('BSC')} onChange={handleInputChange} /> BSC
        </label>
      </div>
      <div>
        <label>Img Upload</label>
        <input type="file" onChange={handleFileUpload} />
      </div>
      <div>
        <button type="submit">Submit</button>
      </div>
    </form>
  );
};

export default CreateUser;

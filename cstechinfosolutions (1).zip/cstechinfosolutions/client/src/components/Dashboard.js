import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  return (
    <div>
      <h1>Welcome to the Admin Panel</h1>
      <Link to="/create-user">Create User</Link>
      <Link to="/user-list">User List</Link>
    </div>
  );
};

export default Dashboard;

import React, { useMemo } from 'react';
import { useTable, useGlobalFilter, useSortBy, usePagination } from 'react-table';
import { BsPencilSquare, BsTrash } from 'react-icons/bs';

const UserList = () => {
  const data = useMemo(
    () => [
      {
        id: 1,
        name: 'hukum',
        email: 'hcgupta@cstech.in',
        mobileNo: '8920729799',
        designation: 'HR',
        gender: 'Male',
        course: 'MCA',
        createDate: '13-Aug-23',
      },
      {
        id: 2,
        name: 'manish',
        email: 'manish@cstech.in',
        mobileNo: '8920729798',
        designation: 'Sales',
        gender: 'Male',
        course: 'BCA',
        createDate: '13-Aug-23',
      },
      {
        id: 3,
        name: 'yash',
        email: 'yash@cstech.in',
        mobileNo: '8920729788',
        designation: 'Operations',
        gender: 'Male',
        course: 'BSC',
        createDate: '13-Aug-23',
      },
      {
        id: 4,
        name: 'prachi',
        email: 'Prachi@cstech.in',
        mobileNo: '8920729765',
        designation: 'HR',
        gender: 'Female',
        course: 'MCA',
        createDate: '13-Aug-23',
      },
    ],
    []
  );

  const columns = useMemo(
    () => [
      {
        Header: 'Unique Id',
        accessor: 'id',
      },
      {
        Header: 'Image',
        accessor: 'image', // You can add image rendering logic here
      },
      {
        Header: 'Name',
        accessor: 'name',
      },
      {
        Header: 'Email',
        accessor: 'email',
      },
      {
        Header: 'Mobile No',
        accessor: 'mobileNo',
      },
      {
        Header: 'Designation',
        accessor: 'designation',
      },
      {
        Header: 'Gender',
        accessor: 'gender',
      },
      {
        Header: 'Course',
        accessor: 'course',
      },
      {
        Header: 'Create Date',
        accessor: 'createDate',
      },
      {
        Header: 'Action',
        accessor: 'action',
        Cell: () => (
          <div>
            <button>
              <BsPencilSquare /> Edit
            </button>
            <button>
              <BsTrash /> Delete
            </button>
          </div>
        ),
      },
    ],
    []
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    page,
    setGlobalFilter,
    state: { globalFilter, pageIndex, pageSize },
    gotoPage,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageCount,
    setPageSize,
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0, pageSize: 5 },
    },
    useGlobalFilter,
    useSortBy,
    usePagination
  );

  return (
    <div>
      <h2>User List</h2>
      <div>
        Search: <input value={globalFilter || ''} onChange={(e) => setGlobalFilter(e.target.value)} />
      </div>
      <table {...getTableProps()} className="table">
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                  {column.render('Header')}
                  <span>{column.isSorted ? (column.isSortedDesc ? ' 🔽' : ' 🔼') : ''}</span>
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {page.map((row) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map((cell) => (
                  <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="pagination">
        <span>
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageCount}
          </strong>{' '}
        </span>
        <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
          {'<<'}
        </button>
        <button onClick={() => previousPage()} disabled={!canPreviousPage}>
          {'<'}
        </button>
        <button onClick={() => nextPage()} disabled={!canNextPage}>
          {'>'}
        </button>
        <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
          {'>>'}
        </button>
        <select value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
          {[5, 10, 20].map((size) => (
            <option key={size} value={size}>
              Show {size}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default UserList;

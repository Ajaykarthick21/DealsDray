import React, { useState } from 'react';

const UserEdit = () => {
  // Define state variables for user details
  const [name, setName] = useState('hukum');
  const [email, setEmail] = useState('hcgupta@cstech.in');
  const [mobileNo, setMobileNo] = useState('954010044');
  const [designation, setDesignation] = useState('Sales');
  const [gender, setGender] = useState('Male');
  const [courses, setCourses] = useState(['MCA']); // Use an array for multiple courses
  const [image, setImage] = useState(null);

  // Function to handle course checkbox changes
  const handleCourseChange = (course) => {
    if (courses.includes(course)) {
      // If the course is already in the list, remove it
      setCourses(courses.filter((c) => c !== course));
    } else {
      // If the course is not in the list, add it
      setCourses([...courses, course]);
    }
  };

  // Function to handle file input change
  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setImage(selectedFile);
  };

  // Function to handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Send updated user details to the server or update them in your state/DB
    // You can access the updated values in the state variables (name, email, etc.)
  };

  return (
    <div>
      <h2>Edit User</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label>Email</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label>Mobile No</label>
          <input type="text" value={mobileNo} onChange={(e) => setMobileNo(e.target.value)} />
        </div>
        <div>
          <label>Designation</label>
          <select value={designation} onChange={(e) => setDesignation(e.target.value)}>
            <option value="Sales">Sales</option>
            <option value="HR">HR</option>
            <option value="Operations">Operations</option>
          </select>
        </div>
        <div>
          <label>Gender</label>
          <div>
            <input
              type="radio"
              name="gender"
              value="Male"
              checked={gender === 'Male'}
              onChange={() => setGender('Male')}
            />
            <label>Male</label>
          </div>
          <div>
            <input
              type="radio"
              name="gender"
              value="Female"
              checked={gender === 'Female'}
              onChange={() => setGender('Female')}
            />
            <label>Female</label>
          </div>
        </div>
        <div>
          <label>Course</label>
          <div>
            <input
              type="checkbox"
              value="MCA"
              checked={courses.includes('MCA')}
              onChange={() => handleCourseChange('MCA')}
            />
            <label>MCA</label>
          </div>
          <div>
            <input
              type="checkbox"
              value="BCA"
              checked={courses.includes('BCA')}
              onChange={() => handleCourseChange('BCA')}
            />
            <label>BCA</label>
          </div>
          <div>
            <input
              type="checkbox"
              value="BSC"
              checked={courses.includes('BSC')}
              onChange={() => handleCourseChange('BSC')}
            />
            <label>BSC</label>
          </div>
        </div>
        <div>
          <label>Img Upload</label>
          <input type="file" accept="image/*" onChange={handleFileChange} />
        </div>
        <div>
          <button type="submit">Update</button>
        </div>
      </form>
    </div>
  );
};

export default UserEdit;

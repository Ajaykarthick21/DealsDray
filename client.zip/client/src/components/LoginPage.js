import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import './LoginPage.css';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState([]);
  const handleLogin = (e) => {
    e.preventDefault();

    const validationErrors = [];

    if (!username.trim()) {
      validationErrors.push({ field: 'username', message: 'Username is required' });
    }
    if (!password) {
      validationErrors.push({ field: 'password', message: 'Password is required' });
    }

    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    console.log(username);
    console.log(password);
  };
  const getErrorMessage = (fieldName) => {
    const error = errors.find((err) => err.field === fieldName);
    return error ? error.message : '';
  };

  return (
    <div>
      <h1>Login Page</h1>
      <form onSubmit={handleLogin}>
      <div>
  <label htmlFor='username'>Login UserName</label>
  <input 
    type='text'
    id='username'
    value={username}
    onChange={e => setUsername(e.target.value)}
  />
  {errors.length > 0 && <p className='error'>{getErrorMessage('username')}</p>}
</div>
<div>
  <label htmlFor='password'>Password</label>
  <input 
    type='password'
    id='password'
    value={password}
    onChange={e => setPassword(e.target.value)}
  />
  {errors.length > 0 && <p className='error'>{getErrorMessage('password')}</p>}
</div>

<button type="submit">Login</button>

      </form>
      <p>Don't have an account? <Link to="/dashboard">Go to Dashboard</Link></p>
    </div>
  );
};

export default LoginPage;

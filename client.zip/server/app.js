const cors = require('cors');
const express = require('express');
const userPostController = require("./db/usersData")


const app = express();

app.use(cors({
    origin: "http://localhost:3000"
}))
app.use(express.json());

// routers
app.post('/user',)

module.exports = app;